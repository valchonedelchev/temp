require('./angular-messages');
module.exports = 'ngMessages';
